package com.example.myapplication_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignIn extends AppCompatActivity {
    EditText emailAddress;
    EditText password;
    Button btn_signIn;
    TextView intentToSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailAddress = findViewById(R.id.emailAddress);
        password = findViewById(R.id.password);
        btn_signIn = findViewById(R.id.btn_signIn);
        intentToSignUp = findViewById(R.id.intentToSignUp);




    }
}